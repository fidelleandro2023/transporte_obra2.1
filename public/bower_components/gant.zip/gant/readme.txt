DHTMLX Gantt
============

Version 5.2.0, Standard Edition


License
------------

GPL-2.0 License, check license.txt for more details


Useful links
-------------

- Product Information
	https://dhtmlx.com/docs/products/dhtmlxGantt/

- Online  documentation
	https://docs.dhtmlx.com/gantt/
	
- Support forum
	https://forum.dhtmlx.com/viewforum.php?f=15