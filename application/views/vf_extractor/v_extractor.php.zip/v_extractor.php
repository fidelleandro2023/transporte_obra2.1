<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from byrushan.com/projects/material-admin/app/2.0/jquery/bs4/hidden-sidebar.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 07 Jul 2017 17:16:44 GMT -->
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Vendor styles -->
        <link rel="stylesheet" href="<?php echo base_url();?>public/bower_components/material-design-iconic-font/dist/css/material-design-iconic-font.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>public/bower_components/animate.css/animate.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>public/bower_components/jquery.scrollbar/jquery.scrollbar.css">
        <link rel="stylesheet" href="<?php echo base_url();?>public/bower_components/fullcalendar/dist/fullcalendar.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>public/bower_components/dropzone/dist/dropzone.css">
        <link rel="stylesheet" href="<?php echo base_url();?>public/bower_components/sweetalert2/dist/sweetalert2.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>public/bower_components/notify/pnotify.custom.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>public/bower_components/select2/dist/css/select2.min.css">
        <!-- App styles -->
        <link rel="stylesheet" href="<?php echo base_url();?>public/css/app.min.css">
    </head>

    <body data-ma-theme="entel">
        <main class="main">
            <div class="page-loader">
                <div class="page-loader__spinner">
                    <svg viewBox="25 25 50 50">
                        <circle cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" />
                    </svg>
                </div>
            </div>

            <header class="header">
                <div class="navigation-trigger" data-ma-action="aside-open" data-ma-target=".sidebar">
                    <div class="navigation-trigger__inner">
                        <i class="navigation-trigger__line"></i>
                        <i class="navigation-trigger__line"></i>
                        <i class="navigation-trigger__line"></i>
                    </div>
                </div>

                <div class="header__logo hidden-sm-down" style="text-align: center;">
                   <a href="" title=""><img src="<?php echo base_url();?>public/img/logo/company_logo.png" alt="Logo Entel" style="width: 36%; margin-left: -51%"></a>
                </div>

                 <?php include('application/views/v_opciones.php'); ?>
            </header>

            <aside class="sidebar sidebar--hidden">
                <div class="scrollbar-inner">
                    <div class="user">
                        <div class="user__info" data-toggle="dropdown">
                            <img class="user__img" src="<?php echo base_url();?>public/demo/img/profile-pics/8.jpg" alt="">
                            <div>
                                <div class="user__name"><?php echo $this->session->userdata('usernameSession')?></div>
                                <div class="user__email"><?php echo $this->session->userdata('descPerfilSession')?></div>
                            </div>
                        </div>

                       
                    </div>

                    <ul class="navigation">

						         <?php echo $opciones?>
                    </ul>
                </div>
            </aside>

            <aside class="chat">
                <div class="chat__header">
                    <h2 class="chat__title">Chat <small>Currently 20 contacts online</small></h2>

                    <div class="chat__search">
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Search...">
                            <i class="form-group__bar"></i>
                        </div>
                    </div>
                </div>

                <div class="listview listview--hover chat__buddies scrollbar-inner">
                    <a class="listview__item chat__available">
                        <img src="<?php echo base_url();?>public/demo/img/profile-pics/7.jpg" class="listview__img" alt="">

                        <div class="listview__content">
                            <div class="listview__heading">Jeannette Lawson</div>
                            <p>hey, how are you doing.</p>
                        </div>
                    </a>

                    <a class="listview__item chat__available">
                        <img src="<?php echo base_url();?>public/demo/img/profile-pics/5.jpg" class="listview__img" alt="">

                        <div class="listview__content">
                            <div class="listview__heading">Jeannette Lawson</div>
                            <p>hmm...</p>
                        </div>
                    </a>

                    <a class="listview__item chat__away">
                        <img src="<?php echo base_url();?>public/demo/img/profile-pics/3.jpg" class="listview__img" alt="">

                        <div class="listview__content">
                            <div class="listview__heading">Jeannette Lawson</div>
                            <p>all good</p>
                        </div>
                    </a>

                    <a class="listview__item">
                        <img src="<?php echo base_url();?>public/demo/img/profile-pics/8.jpg" class="listview__img" alt="">

                        <div class="listview__content">
                            <div class="listview__heading">Jeannette Lawson</div>
                            <p>morbi leo risus portaac consectetur vestibulum at eros.</p>
                        </div>
                    </a>

                    <a class="listview__item">
                        <img src="<?php echo base_url();?>public/demo/img/profile-pics/6.jpg" class="listview__img" alt="">

                        <div class="listview__content">
                            <div class="listview__heading">Jeannette Lawson</div>
                            <p>fusce dapibus</p>
                        </div>
                    </a>

                    <a class="listview__item chat__busy">
                        <img src="<?php echo base_url();?>public/demo/img/profile-pics/9.jpg" class="listview__img" alt="">

                        <div class="listview__content">
                            <div class="listview__heading">Jeannette Lawson</div>
                            <p>cras mattis consectetur purus sit amet fermentum.</p>
                        </div>
                    </a>
                </div>

                <a href="messages.html" class="btn btn--action btn--fixed btn-danger"><i class="zmdi zmdi-plus"></i></a>
            </aside>

            <section class="content content--full">
           
		                   <div class="content__inner">
                                    <h2 style="color: #333333d4;font-weight: 800;text-align: center;">EXTRACTOR</h2>
		   				                    <div class="card">
		   				                        
		   				                        <?php echo $listartabla ?>
		   				                       
		   				                    </div>
		   				                    <!--
		   				                    <button onclick="testTerminoObra()">hola3</button> -->
		   				                    
		   				                </div>
                                            
                                            
                                            
		   				                <footer class="footer hidden-xs-down">
		   				                    <p>© Material Admin Responsive. All rights reserved.</p>

		   				                    <ul class="nav footer__nav">
		   				                        <a class="nav-link" href="#">Homepage</a>

		   				                        <a class="nav-link" href="#">Company</a>

		   				                        <a class="nav-link" href="#">Support</a>

		   				                        <a class="nav-link" href="#">News</a>

		   				                        <a class="nav-link" href="#">Contacts</a>
		   				                    </ul>
		                   </footer>
            </section>
        </main>
        
        <div style="visibility:hidden;">
            <form action="generarExcelCrecVertical" method="POST" id="formGenerarExcel">
            </form>
        </div>
       
       
       <div style="visibility:hidden;">
            <form action="excelplan" method="POST" id="formGenerarPO">
            </form>
        </div>

        <div style="visibility:hidden;">
            <form action="excelplanD" method="POST" id="formGenerarPOD">
            </form>
        </div>

        <!-- Javascript -->
        <!-- ..vendors -->
        <script src="<?php echo base_url();?>public/bower_components/jquery/dist/jquery.min.js"></script>
        <script src="<?php echo base_url();?>public/bower_components/tether/dist/js/tether.min.js"></script>
        <script src="<?php echo base_url();?>public/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>public/bower_components/Waves/dist/waves.min.js"></script>
        <script src="<?php echo base_url();?>public/bower_components/jquery.scrollbar/jquery.scrollbar.min.js"></script>
        <script src="<?php echo base_url();?>public/bower_components/jquery-scrollLock/jquery-scrollLock.min.js"></script>
        <script src="<?php echo base_url();?>public/bower_components/Waves/dist/waves.min.js"></script>

        <script src="<?php echo base_url();?>public/bower_components/flot/jquery.flot.js"></script>
        <script src="<?php echo base_url();?>public/bower_components/flot/jquery.flot.resize.js"></script>
        <script src="<?php echo base_url();?>public/bower_components/flot.curvedlines/curvedLines.js"></script>
        <script src="<?php echo base_url();?>public/bower_components/jqvmap/dist/jquery.vmap.min.js"></script>
        <script src="<?php echo base_url();?>public/bower_components/jqvmap/dist/maps/jquery.vmap.world.js"></script>
        <script src="<?php echo base_url();?>public/bower_components/jquery.easy-pie-chart/dist/jquery.easypiechart.min.js"></script>
        <script src="<?php echo base_url();?>public/bower_components/salvattore/dist/salvattore.min.js"></script>
        <script src="<?php echo base_url();?>public/jquery.sparkline/jquery.sparkline.min.js"></script>
        <script src="<?php echo base_url();?>public/bower_components/moment/min/moment.min.js"></script>
        <script src="<?php echo base_url();?>public/bower_components/fullcalendar/dist/fullcalendar.min.js"></script>

   <!--  tables -->
		<script src="<?php echo base_url();?>public/bower_components/datatables.net/js/jquery.dataTables.min.js"></script>
		<script src="<?php echo base_url();?>public/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
		<script src="<?php echo base_url();?>public/bower_components/datatables.net-buttons/js/buttons.print.min.js"></script>
		<script src="<?php echo base_url();?>public/bower_components/jszip/dist/jszip.min.js"></script>
        <script src="<?php echo base_url();?>public/bower_components/datatables.net-buttons/js/buttons.html5.min.js"></script>

        <script src="<?php echo base_url();?>public/bower_components/dropzone/dist/min/dropzone.min.js"></script>
        <!-- Charts and maps-->
        <script src="<?php echo base_url();?>public/demo/js/flot-charts/curved-line.js"></script>
        <script src="<?php echo base_url();?>public/demo/js/flot-charts/line.js"></script>
        <script src="<?php echo base_url();?>public/demo/js/flot-charts/chart-tooltips.js"></script>
        <script src="<?php echo base_url();?>public/demo/js/other-charts.js"></script>
        <script src="<?php echo base_url();?>public/demo/js/jqvmap.js"></script>
        
        <!-- App functions and actions -->
        <script src="<?php echo base_url();?>public/js/app.min.js"></script>
        
        <!--  -->
        <script src="<?php echo base_url();?>public/bower_components/sweetalert2/dist/sweetalert2.min.js"></script>
        <script src="<?php echo base_url();?>public/bower_components/notify/pnotify.custom.min.js"></script>
        <script src="<?php echo base_url();?>public/bower_components/select2/dist/js/select2.full.min.js"></script>
        <script src="<?php echo base_url();?>public/js/Utils.js"></script>
        <script type="text/javascript">
        
         function testPTRAprobMatFO(){
        	$.ajax({
     	    	type	:	'POST',
     	    	'url'	:	'https://gicsapps.com:8080/obras2/recibir_dis.php',
     	    	data	:	{   ptr   : '2018-12345678',
     	    	                itemplan :'18-0311101082',
                 	    	    eecc     : 'LARI',
                 	    	    jefatura    : 'LIMA SUR',
                 	    	    fecha : '2018-06-29',
     	    	                vr : '12345678'},
     	    	'async'	:	false
     	    })
     	    .done(function(data){             	    
     	    	var data	=	JSON.parse(data);
     	    	console.log('return:'+JSON.stringify(data));    
     	    	/*
     	    	if(data.error == 0){
         	    	console.log('ok:'+JSON.stringify(data));    
     			}else if(data.error == 1){     				
     				console.log('error:'+JSON.stringify(data));
     			}*/
     		  })
        }
          function testTerminoObra(){
        	$.ajax({
     	    	type	:	'POST',
     	    	'url'	:	'sendSisegoTrama3',     	    
     	    	'async'	:	false
     	    })
     	    .done(function(data){      
     	    	console.log('return:'+data);   
     	    	console.log('return:'+JSON.stringify(data));           	    
     	    	var data	=	JSON.parse(data);
     	    	console.log('return:'+JSON.stringify(data));    
     	    
     		  })
        }
              /*
      function testTerminoObra(){
                                        var ptr 		= '2018-31155370';
	 	  	                       	   	var itemplan 	= '18-0320500216';
		 	  	                       	var eecc 		= 'LARI';
			 	  	                    var jefatura 	= 'HUANCAYO';
				 	  	                var fecha 		= '2018-07-09';
					 	  	            var vr 			= '4118095';
						 	  	        var sisego 		= '2018-05-44471';
	 	  	                       	   $.ajax({
		  	                   	    	type	:	'POST',
		  	                   	    	'url'	:	'https://gicsapps.com:8080/obras2/recibir_dis.php',
		  	                   	    	 data	:	{   ptr   		: ptr,
		  	                   	    	                itemplan 	: itemplan,
		  	                               	    	    eecc     	: eecc,
		  	                               	    	    jefatura 	: jefatura,
		  	                               	    	    fecha 		: fecha,
		  	                   	    	                vr 			: vr,
				  	                   	    	        sisego 		: sisego	},											     	    	                						     	    	               
  	                   	    			'async'	:	false
		  	                   	    })
		  	                   	    .done(function(data2){
		  	                   	        
		  	                   	    	var data	=	JSON.parse(data2);
		  	                   	    	console.log('return:'+JSON.stringify(data));		  	                   	    	
		  	                   	    	if(data.error == 0){
			  	                   	    	$.ajax({
	                                  		    type: "POST",
	                                  		    'url' : "saveLogSigo",
	                                  		    data: { origen 		: 'BANDEJA DE APROBACIONT PTR FO - MAT',
	                                      		    	ptr			: ptr,
	                                      		    	itemplan 	: itemplan,
	                                      		    	vr 			: vr,
	                                      		    	sisego 		: sisego,
	                                      		    	eecc 		: eecc,
	                                      		    	jefatura 	: jefatura,
	                                      		    	motivo_error: 'TRAMA COMPLETADA',
	                                      		    	descripcion : 'OPERACION REALIZADA CON EXITO',
	                                      		    	estado 		: '1'},
	                                  		    'async' : false
	                                  		})
		  	                   			}else {
		  	                   			    console.log('else');	
			  	                   			$.ajax({
	                                  		    type: "POST",
	                                  		    'url' : "saveLogSigo",
		                                  		  data: { origen 		: 'BANDEJA DE APROBACIONT PTR FO - MAT',
    	                                      		    	ptr			: ptr,
    	                                      		    	itemplan 	: itemplan,
    	                                      		    	vr 			: vr,
    	                                      		    	sisego 		: sisego,
    	                                      		    	eecc 		: eecc,
    	                                      		    	jefatura 	: jefatura,
    	                                      		    	motivo_error: 'FALLA EN LA RESPUESTA DEL HOSTING',
    	                                    		    	descripcion : 'OPERACION NO COMPLETADA ERROR EN EL SERVIDOR DEL CLIENTE',
    	                                    		    	estado 		: '2'},
	                                  		    'async' : false
	                                  		})
		  	                   				
		  	                   			}
		  	                   		  }).fail(function(jqXHR, textStatus, errorThrown) {
			  	                   		                          		console.log('fail');	
                              			$.ajax({
                                  		    type: "POST",
                                  		    'url' : "saveLogSigo",
                                    		  data: { origen 		: 'BANDEJA DE APROBACIONT PTR FO - MAT',
                                          		    	ptr			: ptr,
                                          		    	itemplan 	: itemplan,
                                          		    	vr 			: vr,
                                          		    	sisego 		: sisego,
                                          		    	eecc 		: eecc,
                                          		    	jefatura 	: jefatura,
                                          		    	motivo_error: 'FALLA DE CONEXCION',
                                          		    	descripcion : 'OPERACION NO COMPLETADA, SE PERDIO LA CONEXCION CON SIGOPLUS',
                                          		    	estado 		: '3'},
                                  		    'async' : false
                                  		})
                         		  })
        }*/
        
        function generarCSVPO() {
            $('#formGenerarPO').submit();
        }
        
        function generarCSVPOD() {
            $('#formGenerarPOD').submit();
        }
        
        
        function asignarGrafo(component){


        	swal({
                title: 'Está seguro de actualizar el estado a 01?',
                text: 'Asegurese de validar la información seleccionada!',
                type: 'warning',
                showCancelButton: true,
                buttonsStyling: false,
                confirmButtonClass: 'btn btn-primary',
                confirmButtonText: 'Si, actualizar estado!',
                cancelButtonClass: 'btn btn-secondary'
            }).then(function(){

            	var id_ptr = $(component).attr('data-ptr');
             	var grafo = $(component).attr('data-grafo');

             	var subProy = $.trim($('#selectSubProy').val()); 
             	var eecc = $.trim($('#selectEECC').val()); 
             	var zonal = $.trim($('#selectZonal').val()); 
             	var item = $.trim($('#selectHasItemPlan').val()); 
             	var mes = $.trim($('#selectMesEjec').val()); 
             	var area = $.trim($('#selectArea').val()); 
             	             	
         	    $.ajax({
         	    	type	:	'POST',
         	    	'url'	:	'updtTo01',
         	    	data	:	{id_ptr	:	id_ptr,
          	    	             grafo : grafo,
            	    	           subProy : subProy,
            	    	           eecc : eecc,
            	    	           zonal : zonal,
            	    	           item : item,
            	    	           mes : mes,
            	    	           area : area},
         	    	'async'	:	false
         	    })
         	    .done(function(data){             	    
         	    	var data	=	JSON.parse(data);
         	    	if(data.error == 0){
             	    	          	    	   
         	    		mostrarNotificacion('success','Operación éxitosa.',data.msj);
         	    		$('#contTabla').html(data.tablaAsigGrafo)
           	    	    initDataTable('#data-table');
         			}else if(data.error == 1){
         				
         				mostrarNotificacion('error','Error el asociar Grafo',data.msj);
         			}
         		  })
         		  .fail(function(jqXHR, textStatus, errorThrown) {
         		     mostrarNotificacion('error','Error al insertar',errorThrown+ '. Estado: '+textStatus);
         		  })
         		  .always(function() {
         	  	 
         		});
         	   
            });            
          	 
        }

        function filtrarTabla(){
     	     var subProy = $.trim($('#selectSubProy').val()); 
           	 var eecc = $.trim($('#selectEECC').val()); 
           	 var zonal = $.trim($('#selectZonal').val()); 
            	var item = $.trim($('#selectHasItemPlan').val()); 
             	var mes = $.trim($('#selectMesEjec').val()); 
             	var area = $.trim($('#selectArea').val()); 
             	
       	    $.ajax({
       	    	type	:	'POST',
       	    	'url'	:	'getDataTablePre',
       	    	data	:	{subProy  :	subProy,
               	    		eecc      : eecc,
            	    	    zonal     : zonal,
         	    	           item : item,
        	    	           mes : mes,
        	    	           area : area},
       	    	'async'	:	false
       	    })
       	    .done(function(data){
       	    	var data	=	JSON.parse(data);
       	    	if(data.error == 0){           	    	          	    	   
       	    		$('#contTabla').html(data.tablaAsigGrafo)
       	    	    initDataTable('#data-table');
       	    		
       			}else if(data.error == 1){
       				
       				mostrarNotificacion('error','Hubo problemas al filtrar los datos!');
       			}
       		  });
        }
            
        function recogePep(){
            console.log('ok');
            var pep1 = $.trim($('#pep1').val());
            var pep2 = $.trim($('#pep2').val());
            
            console.log(pep1);
            console.log(pep2);
            
            $.ajax({
         	    	type	:	'POST',
         	    	'url'	:	'getPep',
         	    	data	:	{pep1	:	pep1,
          	    	             pep2 : pep2
            	    	           },
         	    	'async'	:	false
         	    })
            
            
        }
            function getPepEdit(component){
                var pep1Edit = $(component).attr('data-pep1');
                var pep2Edit = $(component).attr('data-pep2');
                var id_relacion = $(component).attr('data-id_relacion');
                
                $('#pep1Edit').attr('data-pep1Edit',pep1Edit);
                
                
            }
        
        function generarExcelCrecVer() {
            $('#formGenerarExcel').submit();
        }
        </script>
        <script type="text/javascript">
        $(document).ready(function() {
        $('#refresh').click(function() {
            // Recargo la página
            window.setTimeout('location.reload()', 700);
            alertify.success("Insertado Correctamente");
        });
        });
        </script>
        
        <script src="//cdn.jsdelivr.net/npm/alertifyjs@1.11.0/build/alertify.min.js"></script>
        <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.11.0/build/css/alertify.min.css"/>
        <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.11.0/build/css/themes/bootstrap.min.css"/>
    </body>

<!-- Mirrored from byrushan.com/projects/material-admin/app/2.0/jquery/bs4/hidden-sidebar.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 07 Jul 2017 17:16:44 GMT -->
</html>